#pragma once
#include <iostream>
class shape{
    public:
    virtual void info()
    {
        std::cout<<"I'am shape class"<<std::endl;
    }
};